const camera = document.getElementById("camera");
const cameraButton = document.querySelector(".mirrorControls .controlBtn");
const resetButton = document.querySelectorAll(".mirrorControls .controlBtn")[1];
const placeholder = document.querySelector(".cameraPlaceholder");
const shirtOverlay = document.getElementById("shirtOverlay");
const products = Array.from(document.querySelectorAll(".product"));

let stream = null;

const shirts = [
  "assets/shirts/shirt1.svg",
  "assets/shirts/shirt2.svg",
  "assets/shirts/shirt3.svg",
  "assets/shirts/shirt4.svg",
  "assets/shirts/shirt5.svg",
  "assets/shirts/shirt6.svg"
];

const demoData = [
  ["96%", "Good", "27 C", "College", "Pair with beige chinos and white sneakers."],
  ["94%", "Good", "27 C", "Office", "Pair with dark trousers and formal shoes."],
  ["98%", "Good", "26 C", "Casual", "Pair with blue jeans and white sneakers."],
  ["95%", "Good", "25 C", "Everyday", "Pair with neutral chinos for a relaxed look."],
  ["97%", "Good", "28 C", "Streetwear", "Pair with relaxed-fit jeans and sneakers."],
  ["99%", "Good", "18 C", "Winter", "Layer with jeans and a warm jacket."]
];

function selectProduct(index) {
  if (index < 0 || index >= products.length) return;

  products.forEach((product, i) => {
    product.classList.toggle("active", i === index);
  });

  if (shirtOverlay) {
    shirtOverlay.src = shirts[index];
    shirtOverlay.style.opacity = "1";
  }

  const data = demoData[index];
  document.querySelectorAll(".metric strong").forEach((metric, i) => {
    if (data[i] !== undefined) metric.textContent = data[i];
  });

  const recommendation = document.querySelector(".recommendation p");
  if (recommendation) recommendation.textContent = data[4];

  const aiStatus = document.querySelector(".aiStatus");
  if (aiStatus) aiStatus.textContent = "Preview mode - AI fitting not connected";

  const statusItems = document.querySelectorAll(".statusItem h3");
  if (statusItems[0]) statusItems[0].textContent = "Demo";
  if (statusItems[1]) statusItems[1].textContent = "Not detected";
  if (statusItems[2]) statusItems[2].textContent = "Demo mode";
}

async function startCamera() {
  if (!camera) {
    alert("Camera video element was not found in the page.");
    return;
  }

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    alert("Open the app at http://127.0.0.1:8000/ or localhost and allow camera access.");
    return;
  }

  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user" },
      audio: false
    });

    camera.srcObject = stream;
    await camera.play();

    if (placeholder) placeholder.style.display = "none";
    if (cameraButton) cameraButton.textContent = "Camera On";
  } catch (error) {
    console.error("Camera error:", error);
    alert("Camera could not start: " + error.name + ". Check browser permissions and close other apps using the camera.");
    stopCamera();
  }
}

function stopCamera() {
  if (stream) {
    stream.getTracks().forEach(track => track.stop());
    stream = null;
  }

  if (camera) camera.srcObject = null;
  if (placeholder) placeholder.style.display = "flex";
  if (cameraButton) cameraButton.textContent = "Camera";
}

if (cameraButton) {
  cameraButton.addEventListener("click", () => {
    if (stream) stopCamera();
    else startCamera();
  });
}

if (resetButton) {
  resetButton.addEventListener("click", () => {
    stopCamera();
    selectProduct(0);
  });
}

products.forEach((product, index) => {
  product.addEventListener("click", () => selectProduct(index));
});

selectProduct(0);
